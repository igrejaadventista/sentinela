<?php

/**
 * 
 * 
 * GOOD SAFETY PRACTICES
 * 
 */