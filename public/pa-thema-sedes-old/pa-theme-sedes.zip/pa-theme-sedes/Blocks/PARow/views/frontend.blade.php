<div class="row pt-5">
	<InnerBlocks allowedBlocks="{!! esc_attr(wp_json_encode($block['allowed_blocks'])) !!}" />
</div>